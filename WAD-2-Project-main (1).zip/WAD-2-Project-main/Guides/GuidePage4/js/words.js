let words = [
    {
        word: "Backtest",
        hint: "What you should do with your plan before executing in real markets"
    },
    {
        word: "Risk-Management Plan",
        hint: "(Two words) Plan that contains all the risk assessment, analysis, tolerance, and mitigation considerations"
    },
    {
        word:"Market Sentiment",
        hint:" To the overall attitude of investors toward a particular security or financial market"
    }
    
]