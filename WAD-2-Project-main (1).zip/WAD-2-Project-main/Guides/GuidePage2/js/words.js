let words = [
    {
        word: "Centralised",
        hint: "Control of an activity or organization) under a single authority"
    },
    {
        word: "Liquidity",
        hint: "Measurement of how quickly its assets can be converted to cash in the short-term to meet short-term debt obligations"
    },
    {
        word:"Key",
        hint:"A secure code that enables the holder to make cryptocurrency transactions and prove ownership of their holdings"

    },
    {
        word:"Custodial",
        hint:"A type of wallet that allows the user to initiate a transaction through their platform of choice and selects a wallet address to which they'd like to send funds"
    },
    {
        word:"Rug Pull",
        hint:"A cryptocurrency scam in which a developer attracts investors but pulls out before the project is complete, leaving buyers with a worthless asset"
    }
]
