let words = [
    {
        word: "Non-fungible",
        hint: "Not easy to exchange or mix with other similar goods or assets"
    },
    {
        word: "decentralised",
        hint: "(of an activity or organization) Controlled by several local offices or authorities rather than one single one"
    },
    {
        word: "tokens",
        hint: "A virtual currency token or a denomination of a cryptocurrency"
    },
    {
        word: "exchange",
        hint: "The act of trading"
    },
    {
        word: "Cryptocurrency",
        hint: "a digital currency in which transactions are verified and records maintained by a decentralized system using cryptography, rather than by a centralized authority."
    }
]